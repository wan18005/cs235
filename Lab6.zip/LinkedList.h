#pragma once
#include "LinkedListInterface.h"
#include <sstream>
using namespace std;

template<typename T>

class LinkedList : public LinkedListInterface<T>
{
private:
/*********************************************
  * Some of the code is copy from the vector example,
	* and following the video
**********************************************/
	struct Node 
	{
	 T data;
	 Node* next;
	 Node(const T& the_data, Node* next_val = NULL) :
	   data(the_data) {next = next_val;}
	};
	
	Node* myList;
	int numItems;

public:

	LinkedList(void) 
	{ 
		myList = NULL;
		numItems = 0;
		//cout << "In constructor" << endl;
	};
	virtual ~LinkedList(void) 
	{
		//cout << "In deconstructor" << endl;
		clear();
	};

/*
*Construct a Single-Linked List that 
*can be used with template classes 
*and that passes all of the Test *Driver's insertion tests consisting 
*of file1.txt and file2.txt
* These will test your insertHead, insertTail, and insertAfter functions.
*/

/*********************************************
* insertHead
**********************************************/
	virtual void insertHead(T value)
	{
		// cout << "In insertHead" << endl;
	    Node* tmp = myList;
	    bool isThere = false;
	    if (myList != NULL)
	    {
		    while (tmp != NULL)
		    {
		    	if (tmp -> data == value)
		    	{
		    		isThere = true;
		    	}
		    	tmp = tmp -> next;
		    }
		    if (!isThere)
		    {
		    	tmp = myList;
		    	myList = new Node(value, tmp); // new node happen
		    	numItems++;
		    }
	    }
	    else
	    {
	    	myList = new Node(value, NULL);
	    	numItems++;
	    }
	    return;
	}


/*********************************************
* insertTail
**********************************************/
	virtual void insertTail(T value)
	{
		//cout << "In insertTail" << endl;
	    Node* tmp = myList;
	    bool isThere = false;
	    if (myList != NULL)
	    {;
		    while (tmp -> next != NULL)
		    {
		    	if (tmp -> data == value)
		    	{
		    		isThere = true;
		    	}
		    	tmp = tmp -> next;
		    }
	    	if (tmp -> data == value){isThere = true;}
		    if(!isThere)
		    {
		    	tmp -> next = new Node(value, NULL);
		    	numItems++;
		    }
	    }
	    else
	    {
	    	myList = new Node(value, NULL);
	    	numItems++;
	    }
	    return;
	}

/*********************************************
* insertAfter
**********************************************/
virtual void insertAfter(T value, T insertionNode)
	{
		 //cout << "In InsertAfter"<< endl;
	    Node* tmp = myList;
	    bool isThere = false;
	    if (myList != NULL)
	    {

	    	while (tmp -> next != NULL && !isThere)
		    {
		    	if (tmp -> data == value)
		    	{
		    		isThere = true;
		    	}
		    	tmp = tmp -> next;
		    }
		    if (!isThere)
		    {
		    	tmp = myList;
		    	while (tmp -> next != NULL)
		    	{
		    		if (tmp -> data == insertionNode)
		    		{
		    			Node* tmpNext = tmp -> next;
		    			tmp -> next = new Node(value, tmpNext);
		    			tmp = tmp -> next;
		    			numItems++;
		    			break;
		    		}
		    		else
		    		{
		    			tmp = tmp -> next;
		    		}
		    	}
		    	if (tmp -> data == insertionNode)
		    	{
		    		Node* tmpNext = tmp -> next;
		    		tmp -> next = new Node(value, tmpNext);
		    		numItems++;
		    	}
		    }
	    }
	    return;
	}

/*********************************************
* Remove
* This will test your remove and clear functions. 
* Includes files file3.txt and file4.txt 
**********************************************/

/*********************************************
* Remove
**********************************************/

	virtual void remove(T value)
	{
		Node* tmp = myList;
		if (myList != NULL)
		{
			if (tmp -> data != value)
			{
				while (tmp -> next != NULL)
				{
					if ((tmp -> next) -> data == value)
					{
						Node* tmpAfter = tmp -> next;
						if (tmpAfter != NULL)
						{
							tmpAfter = tmpAfter -> next;
						}
						delete tmp -> next;
						tmp -> next = tmpAfter;
						numItems--;
						break;
					}
					else
					{
						tmp = tmp -> next;
					}
				}
			}
			else
			{
				myList = tmp -> next;
				delete tmp;
				numItems--;
			}
		}
	    return;
	}

/*********************************************
* Clear
**********************************************/
	virtual void clear()
	{
		Node* current = NULL;
	    while (myList != NULL)
		{
			current = myList;
			myList = current->next;
			delete current;
		}
		numItems = 0;
		return;
	}
/*
* No Leaks in the Hull
*Run and pass Valgrind on your program to ensure that you have no memory leaks.
*/

/*********************************************
* T at
* Returns the value of the node at the given index. The list begins at
	index 0.
*  If the given index is out of range of the list, throw an out of range exception.
 **********************************************/
	virtual T at(int index)
	{
	    if(index < 0 || index >= numItems)
	    {
	    	throw out_of_range("at error");
				// This class defines the type of objects thrown as exceptions to report an out-of-range error.
				// cplusplus.com/reference/stdexcept/out_of_range/
	    }
	    else
	    {
	    	Node* tmp = myList;
	    	for(int i = 0; i < index; i++)
	    	{
	    		tmp = tmp -> next;
	    	}
	    	return tmp -> data;
	    }
	}

/*********************************************
* size
* return the number of item in the arr
**********************************************/
	virtual int size()
	{
	    return numItems;
	}


/*********************************************
* toString
* return things in a string 
**********************************************/
	virtual string toString()
	{
	    ostringstream ss;
	    Node* tmp = myList;
	    while (tmp != NULL)
	    {
	    	ss << tmp -> data;
	    	if (tmp -> next != NULL)
	    	{
	    		ss << " ";
	    	}
	    	tmp = tmp -> next;
	    }
	    return ss.str();
	}

};