#include <iostream>
#include <vector>
#include <set>
#include <sstream>
#include <fstream>
#include <map>
#include <list>
using namespace std;
int main(int argc, char *argv[])
{
    vector<string> tokens;
    set <string> unique;
    string next_line;  // Each data line
		string filename = argv[1];
    ifstream in(filename);
    while (getline(in, next_line)) {
        istringstream iss(next_line);
        string token;
        while (iss >> token) {
            string nopunct = "";
            for(auto &c : token) { // Remove Punctuation      
                if (isalpha(c)) {
                    nopunct +=c;       
                }
            }
	          tokens.push_back(nopunct);
		        unique.insert(nopunct);
		    // cout << token<<endl;
	    }
    }
    cout << "Number of words "<<tokens.size()<<endl;
    cout << "Number of unique words "<<unique.size()<<endl;
		ofstream setfile(filename + "_set.txt");

    for (set<string>::iterator it=unique.begin(); it!=unique.end(); ++it)
		{
    //cout << ' ' << *it;
		setfile << ' ' << *it;
    }
		cout << endl;
		



		// put the vector into a map
/*
map<string, vector<string>> wordmap;
string state = "";
for(vector<string>::iterator it=tokens.begin(); it !=tokens.end(); it++) {
  wordmap[state].push_back(*it);
  state = *it;
}
*/
/*
ofstream mapfile(filename + "_map.txt");
for (map<string,string>::iterator it=wordmap.begin(); it!=wordmap.end(); it++) 
{
  cout << "first " << it->first << " Second " << it->second << endl;
	mapfile << it->first << " , " << it->second << endl;
}
*/

/*
string state = "";
for(int i = 0; i < 100; i++){
  cout << wordmap[state] << " ";
  state = wordmap[state];
}
cout << endl;
*/


//part 5
/*
srand(time(NULL)); // this line initializes the random number generated
                   // so you dont get the same thing every time
state = "";
for (int i = 0; i < 100; i++) {
  int ind = rand() % wordmap[state].size();
  cout << wordmap[state][ind] << " ";
  state = wordmap[state][ind];
}
cout << endl;

*/

// part 6



const int M = 3;
// put the vector values into a map
map<list<string>, vector<string>> wordmap;
// set up a list with just empty string
  list<string> state;
  for (int i = 0; i < M; i++) {
    state.push_back("");
  }
                        
  for (vector<string>::iterator it=tokens.begin(); it!=tokens.end(); it++) {
    wordmap[state].push_back(*it);
    state.push_back(*it);
    state.pop_front();
  }
  srand(time(NULL));
	// clear out the state
	state.clear();
	// set it pack to 3(M) blank space
  for (int i = 0; i < M; i++) {
    state.push_back("");
  }

  for (int i = 0; i < 100; i++)
	// generated 100 string  
	{
    int ind = rand() % wordmap[state].size();
		// look up in map pick a random charar
    cout << wordmap[state][ind]<<" ";
		// print it out
    state.push_back(wordmap[state][ind]);
		// push it 
    state.pop_front();
		// pop it the go to the next word
  }



}
