#include <iostream>
#include <string>
#include <sstream>
#include <stack>
#include <cstdlib>
#include "ExpressionManager.h"
using namespace std;

/*********************************************
* ExpressionManager :: checkParenthesis
* Check whether the string have parentesis 
*********************************************/
bool ExpressionManager::checkParenthesis(string value) 
{
	if (value == "(" || value == "{" || value == "[" || value == ")" || value == "}" || value == "]")
	{
        return true;
  }
    else
		{
        return false;
    }
}

/*********************************************
* ExpressionManager :: check for open parentesis
* Check whether the string have parentesis 
*********************************************/
bool ExpressionManager::checkOpenParenthesis(string value) 
{
	if (value == "(" || value == "{" || value == "[")
	{
		return true;
	}
	else 
	{
		return false;
	}
}


/*********************************************
* ExpressionManager :: check for close parentesis
* Check whether the string have parentesis 
*********************************************/
bool ExpressionManager::checkClosedParenthesis(string value) 
{
	if (value == ")" || value == "}" || value == "]")
	{
		return true;
	}
	else 
	{
		return false;
	}
}

/*********************************************
* ExpressionManager :: check operator
* Check whether the string have parentesis 
*********************************************/
bool ExpressionManager::checkOperator(string value) 
{
	if (value == "*" || value == "/" || value == "%" || value == "+" || value == "-") 
	{
		return true;
	}
	else 
	{
		return false;
	}
}
/*********************************************
* ExpressionManager :: check number that is in file
* Check whether the string have parentesis 
*********************************************/
bool ExpressionManager::checkInteger(string value) 
{
	for (int i = 0; i < value.size(); i++) 
	{  
		// Check if character is decimal digit
		// http://www.cplusplus.com/reference/cctype/isdigit/
		// check for intergers is string
		if(!isdigit(value[i])) 
		{
			return false;
		}
	}
	return true;
}

/*********************************************
* ExpressionManager :: the order of operation
* from the video I had set the order
*********************************************/
int ExpressionManager::checkOrder(string value) 
{
	int order;
	if (value == ")" || value == "}" || value == "]") 
	{
		order = 3;
	}
	else if (value == "*" || value == "/" || value == "%") 
	{
		order = 2;
	}
	else if (value == "+" || value == "-") 
	{
		order = 1;
	}
	else if (value == "(" || value == "{" || value == "[")
	{
		order = 0;
	}

	return order;
}
/*********************************************
* ExpressionManager :: checkValidInfix
* check whether the line is a valid infix form
*  I first set the intergers and sign of operation to 0 and pass them into a temp string
* Check for int, operator and parenthesis 
* Since infix notation usually has more intergers so it will automative false 
*********************************************/
bool ExpressionManager::checkValidInfix(string expression) 
{
	int intNumber =0;
	int signNumber=0;
	stringstream ss(expression);
	string temp;

	while (ss >> temp) 
	{
		if (!checkInteger(temp) && !checkOperator(temp) && !checkOpenParenthesis(temp) && !checkClosedParenthesis(temp)) 
		{
			return false;
		}
		else if (checkInteger(temp)) 
		{
			intNumber++;
		}
		else if (checkOperator(temp)) 
		{
			signNumber++;
		}
		if (signNumber > intNumber) 
		{
			return false;
		}
	}
	return true;
}
/*********************************************
* ExpressionManager :: checkValidPostfix
* check whether the line is a valid postfix form
*  I first set the intergers and sign of operation to 0
* Check for int, operator and parenthesis just like before
* Then from some file I notice there are some invalid postfix notation so I put some conditions so it will not pass 
*********************************************/
bool ExpressionManager::checkValidPostfix(string expression) 
{
	int intNumber = 0;
	int signNumber = 0;
	stringstream ss(expression);
	string temp;

	while (ss >> temp) 
	{
		  if (!checkInteger(temp) && !checkOperator(temp) && !checkOpenParenthesis(temp) && !checkClosedParenthesis(temp)) 
		  {
			 return false;
		 }
		  else if (checkInteger(temp)) 
		  {
			  intNumber++;
				
		  }
		  else if (checkOperator(temp)) 
		  {
			  signNumber++;
				
		  }
		  if ((signNumber == 1 && intNumber == 0) || (signNumber == 1 && intNumber == 1) || (signNumber == intNumber)) 
		  {
			  return false;
		  }
	}

if (intNumber - signNumber != 1) 
	{
		return false;
	}
else 
	{
		return true;
	}
}
/*********************************************
* ExpressionManager :: isBalanced
* Create an empty stack of characters.
*Assume that the expression is balanced (balanced is true).
*Set index to 0.
*while balanced is true and index < the expression’s length
*Get the next character in the data string.
*if the next character is an opening parenthesis
*Push it onto the stack.
*else if the next character is a closing parenthesis
*if stack is empty
*set balanced to false
*pop the top of the stack
*if the top is not an open parenthesis that matches the closing parenthesis
*set balanced to false
*Increment index.
*Return true if balanced is true and the stack is empty.
*********************************************/

bool ExpressionManager::isBalanced(string expression) 
{
	stack<string> pStack;
	stringstream ss(expression);
	string temp;
  // stack is empty
	if (expression == "") 
	{
		return false;
	}
 
	while(ss >> temp) 
	{ 
		//Push it onto the stack. 
		if (checkOpenParenthesis(temp)) 
		{
			pStack.push(temp);
		}
		//else if the next character is a closing parenthesis
		//set balanced to false
		else if (checkClosedParenthesis(temp)) 
		{
			if (temp == ")" && !pStack.empty()) 
			{
				string check = pStack.top();
				if (check != "(") 
				{
					return false;
				}
				else 
				{
					pStack.pop();
				}
			}
      // for {}
			else if (temp == "}" && !pStack.empty()) {
				string check = pStack.top();
				if (check != "{") 
				{
					return false;
				}
				else 
				{
					pStack.pop();
				}
			}
			//for []
			else if (temp == "]" && !pStack.empty()) 
			{
				string check = pStack.top();
				if (check != "[") 
				{
					return false;
				}
				else 
				{
					pStack.pop();
				}
			}
		else 
			{
				return false;
			}
		}
	}
	//if the top is not an open parenthesis that matches the closing parenthesis
 // set balanced to false
	if (pStack.size() > 0) 
	{
		return false;
	}
	else 
	{
		return true;
	}
}

/*********************************************
* ExpressionManager :: postfixToInfix
* I had tried using the vector's way but I keep getting error for file 4 and 5 so I took a different approach to this just using string
* The idea is kind of the same with isBanlanced
* first it check for empty space, postfix and parentesis
* Then I pass in the data into a temper string
*********************************************/
string ExpressionManager::postfixToInfix(string postfixExpression) 
{
	stack<string> intStack;
	stringstream ss(postfixExpression);
	string temp;
	string output;
	string left;
	string right;
	//string current_operator;

	if (postfixExpression == "") 
	{
		return "invalid";
	}

	if (!checkValidPostfix(postfixExpression)) 
	{
		return "invalid";
	}

	if (checkParenthesis(postfixExpression)) 
	{
		return "invalid";
	}

	while (ss >> temp) 
	{
		
		if (checkInteger(temp)) 
		{ 
			// push out the intergers
			intStack.push(temp);
		}
      // check for operator 
			// store the int as right and left and change it in to the equaltion
		else if (checkOperator(temp)) 
		{  
			right = intStack.top();
			intStack.pop();
			left = intStack.top();
			intStack.pop();
			output = "( " + left + " " + temp + " " + right + " )";
			intStack.push(output);
		}
	}
	return output;
}

/*********************************************
* ExpressionManager :: inFix to postfix
* I had tried using the vector's way but I keep getting error for file 4 and 5 so I took a different approach to this just using string
* check for conditions
* pass them into a string check for intergers them put the sign to the int as out put
* but if there is open parenthesis and other conditions do the following
*********************************************/
string ExpressionManager::infixToPostfix(string infixExpression) 
{
	stack<string> operatorStack;
	stringstream ss(infixExpression);
	string temp;
	string output;
	string OPstring;

	if (infixExpression == "") 
	{
		return "invalid";
	}

	if (!checkValidInfix(infixExpression)) 
	{
		return "invalid";
	}

	if (!isBalanced(infixExpression)) 
	{
		return "invalid";
	}

	while(ss >> temp) 
	{
		

		if (checkInteger(temp)) 
		{
			output += temp + " ";
		}
    
		else if (checkOpenParenthesis(temp)) 
		{ 
			operatorStack.push(temp); // push the open parenthesis
		}

		else if (checkOperator(temp))  // when there is a operator 
		{
      // check the following
			if (operatorStack.empty() || checkOpenParenthesis(operatorStack.top()))
			{
				operatorStack.push(temp); // them push them
			}

			else if (checkOrder(temp) > checkOrder(operatorStack.top())) 
			{
				operatorStack.push(temp); // compare them with the order of operator
			}

			else if (checkOrder(temp) <= checkOrder(operatorStack.top())) 
			{

				while (!operatorStack.empty() && checkOrder(temp) <= checkOrder(operatorStack.top()) && !checkOpenParenthesis(operatorStack.top())) 
				{ 
					// if those requriement meet them we have 
					OPstring = operatorStack.top();
					operatorStack.pop();
					output += OPstring + " ";
				}

				operatorStack.push(temp);
			}
		}
    // the following else if check for closed parentesis
		else if (checkClosedParenthesis(temp)) 
		{

			while (!checkOpenParenthesis(operatorStack.top())) 
			{
				OPstring = operatorStack.top();
				operatorStack.pop();
				output += OPstring + " ";
			}

			operatorStack.pop();
		}

		else 
		{
			return "invalid";
		}
	}

	while (!operatorStack.empty()) {
		OPstring = operatorStack.top();
		operatorStack.pop();
		output += OPstring + " ";
	}

	output = output.substr(0, output.size() - 1);
	return output;
}

/*********************************************
* ExpressionManager :: postfixEvaluate
* I had tried using the vector's way but I keep getting error for file 4 and 5 so I took a different approach to this just using string
*********************************************/
string ExpressionManager::postfixEvaluate(string postfixExpression) 
{
	stack<string> numberStack;
  stringstream ss(postfixExpression);
	
  int output;
	string left;
	string right;
   // temp string
	string temp;
	if (postfixExpression == "") 
	{
		return "invalid";
	}
	if (!checkValidPostfix(postfixExpression)) 
	{
		return "invalid";
	}
	if (checkParenthesis(postfixExpression)) 
	{
		return "invalid";
	}
	while (ss >> temp) 
	{
		if (checkInteger(temp)) 
		{
			numberStack.push(temp);
		}
		else if (checkOperator(temp)) 
		{
			right = numberStack.top();
			numberStack.pop();
			if (numberStack.empty())
			{
			return "invalid";
			}
			left = numberStack.top();
			numberStack.pop();

			int R = atoi(right.c_str());
			int L = atoi(left.c_str());
		
		    if (temp == "+")
		    {
		        output = L + R;
		    }
		    if (temp == "-")
		    {
		        output = L - R;
		    }
		    if (temp =="*")
		    {
		        output = L * R;
		    }
		     if (temp == "%" )
				  {  
					  if (R==0)
				  {
					  return "invalid";
				  }
				    else
				    {
	 	         output = L % R;
						}
		      }

			   if (temp == "/")  
				 {
			     if (R == 0)
			     {
			       return "invalid";
			     }
			     else
			     {
			      output = L / R;
			     }
				
			   }

			stringstream newss;
			newss << output;
			// push a new string
			numberStack.push(newss.str());
		}
		else
		{
		 return "invalid";
		}
  }
     string answer = numberStack.top();
     return answer;
}

/*
if the operator stack is empty OR the top stack is an opening parenthesis OR the current operator is an opening parenthesis 
Push the current operator onto the stack
return true
else if the current operator is a closing parenthesis
while the top of the operator stack is not a matching opening parenthesis
pop off the top of the stack and append it to postfix (with a space after)
if operator stack becomes empty without finding a matching parenthesis, return false
pop off the matching opening parenthesis
return true
else
while the current operator precedence is less than or equal to the stack top precedence, pop stack onto postfix
operators * / % have high precedence
operators + - have low precedence
everything else has no precedence
push the current operator
return true 

*/
/*
bool ExpressionManager::processOperator(stack<string> &operators, string &token, string &postfix)
*/



/*
vector<string> ExpressionManager::parseTokens(string expression)
{
  stringstream ss(expression);
  string token;
  vector<string> tokens;
  while(getline(ss, token, ' '))
  {
    tokens.push_back(token);
  }
  return tokens;
}



*/