#include "Node.h"
using namespace std;

/*********************************************
* GetData
**********************************************/
int Node::getData() const
{
    return data;
}

/*********************************************
* getLeftChild
**********************************************/
Node * Node::getLeftChild() const
{
    return left;
}

/*********************************************
* getRightChild
**********************************************/
Node * Node::getRightChild() const
{
    return right;
}