#include "BST.h"

/*********************************************
* Default
**********************************************/
BST :: BST() 
{   
	//  cout << "In def-con" << endl;
    root = NULL;
}
BST :: ~BST() 
{  
	//  cout << "In con" << endl;
    clear();
}


/*********************************************
*  getRootNode
**********************************************/
 /*
	* Returns the root node for this tree
	*
	* @return the root node for this tree.
	*/
NodeInterface* BST :: getRootNode() const 
{  // cout << "get root node" << endl;
    return root;
}

/*********************************************
*  add
**********************************************/
 /*
	* Attempts to add the given int to the BST tree
	*
	* @return true if added
	* @return false if unsuccessful (i.e. the int is already in tree)
	*/
bool BST :: add(int data) 
{  
	// cout << "In ADD " << endl;
    if(root == NULL) 
		{
        Node* newRoot = new Node(data);
        root = newRoot;
				// cout << "return true " 
        return true;
    }
    else if(addAdvanced(this->root, data)) 
		{   
			 // cout << "return true "
        return true;
    }
    else 
		{
        return false;
    }
}

bool BST :: addAdvanced(Node* &N, int data) 
{   
	  // cout << "Run in add advance " << endl;
    if(N == NULL) 
		{ 
        N = new Node(data);
        return true;
    }
    else if(N->data < data) 
		{   
			  // cout << addAdvanced(N->right, data) << endl;
        return addAdvanced(N->right, data);
    }
    else if(N->data > data) 
		{   
			  // cout << addAdvanced(N->left, data) << endl;
        return addAdvanced(N->left, data);
    }
    else 
		{
        return false;
    }
}


/*********************************************
*  remove
**********************************************/
 /*
	* Attempts to remove the given int from the BST tree
	*
	* @return true if successfully removed
	* @return false if remove is unsuccessful(i.e. the int is not in the tree)
	*/
bool BST :: remove(int data) 
{   
	  // cout << "in remove " << endl;
    return removeAdvanced(root, data);
}

bool BST :: removeAdvanced(Node* &N, int data) 
{   
	  // cout << "in remove checker " << endl;
    if(N == NULL) 
		{  
        return false;
    }
    else if(data == N->data) 
		{
        if(N->left == NULL && N->right == NULL) 
				{
            Node* tempNode = N;
            N = NULL;
            delete tempNode;
            return true;
        }
        if (N->right != NULL && N->left == NULL) 
				{
            Node* tempNode = N;
            N = N->right;
            delete tempNode;
            return true;
        }
        if (N->right == NULL && N->left != NULL) 
				{
            Node* tempNode = N;
            N = N->left;
            delete tempNode;
            return true;
        }
        else 
				{
            N->data = checkTree(N->left);
            return removeAdvanced(N->left, N->data);
        }
    }
    else if(data < N->data) 
		{
        return removeAdvanced(N->left, data);
    }
    else 
		{
        return removeAdvanced(N->right, data);
    }
}

int BST :: checkTree(Node *N)  
{   // cout << "In check tree" << endl;
    if (N == NULL) 
		{
        return -1;
    }

    int newData = N->data;
    Node* left = N->left;

    if (left != NULL) 
		{
        int leftdata = checkTree(left);
        if (leftdata > newData) 
				{
            newData = leftdata;
        }
    }
    
    Node* right = N->right;
    if (right != NULL) 
		{
        int rightdata = checkTree(right);
        if (rightdata > newData) 
				{
            newData = rightdata;
        }
    }
    return newData;
}

/*********************************************
*  clear
**********************************************/
/*
* Removes all nodes from the tree, resulting in an empty tree.
*/
void BST :: clear() 
{
    clearAdvanced(root);
    root = NULL;
}

void BST :: clearAdvanced(Node* N) 
{
    if(N == NULL) 
		{
        return;
    }
    else if(N->left != NULL) 
		{
        clearAdvanced(N->left);
    }
    else if(N->right != NULL) 
		{
        clearAdvanced(N->right);
    }
    delete N;
    return;
}
