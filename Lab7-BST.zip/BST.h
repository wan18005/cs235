#pragma once
#include "BSTInterface.h"
#include "Node.h"

using namespace std;

class BST : public BSTInterface 
{
public:
    BST();
    virtual ~BST();
    virtual NodeInterface* getRootNode() const;
    virtual bool add(int data);
    virtual bool addAdvanced(Node* &T, int data);
    virtual bool remove(int data);
    virtual bool removeAdvanced(Node* &T, int data);
    virtual void clear();
    virtual void clearAdvanced(Node* T);
    int checkTree(Node* T);
private:
    Node* root;
};

