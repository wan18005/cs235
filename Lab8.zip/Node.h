#pragma once

#include "NodeInterface.h"
#include <iostream>
using namespace std;

class Node : public NodeInterface 
{
    friend class AVL; 
/*
Friend Class A friend class can access private and protected members of other class in which it is declared as friend. It is sometimes useful to allow a particular class to access private members of other class. For example a LinkedList class may be allowed to access private members of Node.
https://www.geeksforgeeks.org/friend-class-function-cpp/
*/
	protected:
		Node * left;
		Node * right;
		int value;
		int height;

	public:
    
		Node(){};

    Node(int value);

    virtual ~Node() {}
    
    virtual int getData() const;
   
    virtual Node * getLeftChild() const;

    virtual Node * getRightChild() const;

    virtual int getHeight();

		virtual int getBalance();


    
};
