#include "AVL.h"

using namespace std;


AVL::AVL() 
{   
	//  cout << "In def-con" << endl;
    root = NULL;
}
AVL::~AVL() 
{   
	//  cout << "In con" << endl;
  clear();
}



Node * AVL::getRootNode() const 
{   
	  // cout << "get root node" << endl;
    return root;
}


/*
Implement the interface creating an AVL tree. Remember to rebalance when the subtree heights are off by more than 1 (i.e. the balance of a node is greater than 1 or less than -1).
*/


bool AVL::add(int data) 
{
    return addAdvanced(root, data);
}

bool AVL::addAdvanced(Node *&T, int data) 
{
    if (T == NULL) 
		{
        T = new Node(data);
				// set height to 0
        T->height = 0;
				// cout << "return true" << endl;
        return true;
    }

		// three situtation 
		// T == data
		// T < data
		// T > data

		// one 
    if (T->value == data) 
		{   
			// cout << "return false" << endl;
        return false;
    }

		// two
    if (T->value < data) 
		{
        bool two = addAdvanced(T->right, data);
        if (two == true) 
				{
            if(T->getBalance() > 1) 
						{
                rotateLeft(T);
            }
            if (T->getBalance() < -1) 
						{
                rotateRight(T);
            }
        }
				// cout << "return second case " << two  << endl;
        return two;
    }

    // three 
    else if (T->value > data) 
		{
        bool three = addAdvanced(T->left, data);
        if (three == true) 
				{
            if (T->getBalance() > 1) 
						{
                rotateLeft(T);
            }
            if(T->getBalance() < -1) 
						{
                rotateRight(T);
            }
        }
				// cout << "return third case " << three  << endl;
        return three;
    }

    if (T->getBalance() > 1) 
		{
        rotateLeft(T);
    }
    if (T->getBalance() < -1) 
		{
        rotateRight(T);
    }
    // cout << "return false " << endl;
    return false;
}




/*
Properly remove from the AVL tree
Maintain balance of the tree
Be sure to follow the conventions outlined in the Requirement Notes to keep a "properly" constructed tree
*/

bool AVL::remove(int data) 
{
    bool remove = removeAdvanced(root, data);
    balance(root, data); 
		// cout << "return remove case " << remove  << endl;
    return remove;
}

bool AVL::removeAdvanced(Node *&T, int data) 
{

    if (T == NULL) 
		{
        return false;
    }
    if (data < T->value) 
		{
        bool One = removeAdvanced(T->left, data);
        balance(T, data);
				// cout << "return 1 case " << One  << endl;
        return One;
    }
    if (data > T->value) 
		{
        bool Two = removeAdvanced(T->right, data);
        balance(T, data);
				// cout << "return 2 case " << Two  << endl;
        return Two;
    }

    if(T->left == NULL && T->right == NULL) 
		{
        delete T;
        T = NULL;
        return true;
    }

    if (T->right != NULL && T->left == NULL) 
		{
        Node* temp = T->right;
        delete T;
        T = temp;
        balance(T, data);
        return true;
    }

    if (T->right == NULL && T->left != NULL) 
		{
        Node* temp = T->left;
        delete T;
        T = temp;
        balance(T, data);
        return true;
    }

    Node* temp = checkTree(T->left);
    temp->left = T->left;
    temp->right = T->right;
    delete T;
    T = temp;
		// cout << "return T case " << T << endl;
    return true;
}

void AVL::clear() 
{
    clearAdvanced(root);
    root = NULL;
}

void AVL::clearAdvanced(Node *T) 
{
    if (T == NULL) 
		{
        return;
    }
    if (T->left != NULL) 
		{
        clearAdvanced(T->left);
    }
    if (T->right != NULL) 
		{
        clearAdvanced(T->right);
    }
    delete T;
    return;
}


Node* AVL::checkTree(Node *&T) 
{
    if (T->right == NULL) 
		{
        Node * tempNode = T;
        T = T->left;
        return tempNode;
    }
    Node *temp = checkTree(T->right);
    balance(T, T->value);
    return temp;
}



void AVL::rotateLeft(Node *&T)
{
    if (T == NULL) 
		{
        return;
    }
    if (T->right->getBalance() <= -1) 
		{
        rotateRightLeft(T->right);
    }
    rotateLeftRight(T);
}

void AVL::rotateRight(Node *&T) 
{
    if (T == NULL) 
		{
        return;
    }
    if (T->left->getBalance() >= 1) 
		{
        rotateLeftRight(T->left);
    }
    rotateRightLeft(T);
}


void AVL::rotateLeftRight(Node *&T) 
{
    Node * newNode = T->right;
    T->right = newNode->left;
    newNode->left = T;
    T = newNode;
}


void AVL::rotateRightLeft(Node* &T) 
{
    Node *newNode = T->left;
    T->left = newNode->right;
    newNode->right = T;
    T = newNode;
}



bool AVL::balance(Node *&T, int data) 
{
    if(T == NULL) 
		{
        return false;
    }
    if (T->getBalance() > 1) 
		{
        rotateLeft(T);
    }
    else if (T->getBalance() < -1) 
		{
        rotateRight(T);
    }
    balance(T->left, data);
    balance(T->right, data);
    return false;
}