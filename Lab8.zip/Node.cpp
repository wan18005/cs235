#include "Node.h"

using namespace std;

Node::Node(int data) 
{
        value = data;
        left = NULL;
        right = NULL;
        height = 0;
}

/*********************************************
* GetData
**********************************************/
int Node::getData() const
{
    return value;
}

/*********************************************
* getleft
**********************************************/
Node * Node::getLeftChild() const
{
    return left;
}

/*********************************************
* getright
**********************************************/
Node * Node::getRightChild() const
{
    return right;
}

/*
	* Returns the height of this node. The height is the number of nodes
	* along the longest path from this node to a leaf.  While a conventional
	* interface only gives information on the functionality of a class and does
	* not comment on how a class should be implemented, this function has been
	* provided to point you in the right direction for your solution.  For an
	* example on height, see page 448 of the text book.
	*
	* @return the height of this tree with this node as the local root.
*/

/*********************************************
* getHeight
**********************************************/
int Node:: getHeight() 
{
        int LHeight = 0;
        int RHeight = 0;
        if (left != NULL) 
				{
            LHeight = left->getHeight();
        }
        if (right != NULL) 
				{
            RHeight = right->getHeight();
        }
        if (LHeight > RHeight) 
				{
            return LHeight + 1;
        }
        else 
				{
            return RHeight + 1;
        }
}

/*********************************************
* getBalance
**********************************************/
    int Node::getBalance() 
		{
        int RHeight;
        int LHeight;
        if (right != NULL) 
				{
            RHeight = right->getHeight();
        }
        else 
				{ 
            RHeight = 0;
        }
        if (left != NULL) 
				{
            LHeight = left->getHeight();
        }
        else 
				{
            LHeight = 0;
        }
        return RHeight - LHeight;
    }

