#pragma once


#include "AVLInterface.h"
#include "Node.h"
#include <iostream>

using namespace std;

class AVL : public AVLInterface 
{
protected:
					Node* root;
public:
    		AVL();
    		virtual ~AVL(); 
    
    		virtual Node * getRootNode() const;
    
		   // add or insert
				bool add(int data);
				bool addAdvanced(Node *&T, int val);
       // remove
    		bool remove(int data);
				bool removeAdvanced(Node *&T, int val);
      // clear
    		void clear();
				void clearAdvanced(Node *T);
			// tree
				Node* checkTree(Node* &T);
      // rotate
    		void rotateLeft(Node *&T);
    		void rotateRight(Node *&T);
    		void rotateRightLeft(Node *&T);
    		void rotateLeftRight(Node *&T);
      // balance
    		bool balance(Node *&T, int val);
};

