#ifndef TODO_LIST_H
#define TODO_LIST_H

#include <iostream>
#include <string>
#include "TodoListInterface.h"
#include <fstream>
#include <vector>
#include <sstream>
using namespace std;

class TodoList: public TodoListInterface {
public:
// declare vector
    vector <string> tasks;
    TodoList() {
      //cout << "In Constructor" << endl;
			 ifstream infile ("TODOList.txt");
			 string line;
       if (infile.is_open())
        {
           while ( getline (infile,line) )
           {
            // cout << line << '\n';
						tasks.push_back(line);
           }

            infile.close();
						
        }
		}


    virtual ~TodoList() {
       //cout << "In Destructor" << endl;
			 ofstream outfile;
       outfile.open ("TODOList.txt", ofstream::out | ofstream::trunc); 
			 for(int i = 0; i < tasks.size(); i++){
				 //cout << tasks[i] << '\n';
				 outfile << tasks[i] << endl;
			 }
       outfile.close();
		}

    /*
    *   Adds an item to the todo list with the data specified by the string "_duedate" and the task specified by "_task"
    */
    virtual void add(string _duedate, string _task)
		{
			//cout << "In add " <<_duedate <<" " <<_task << endl;
			tasks.push_back(_duedate+ " " + _task);
		}

    /*
    *   Removes an item from the todo list with the specified task name
    *
    *   Returns 1 if it removes an item, 0 otherwise
    */
    virtual int remove(string _task)
		{ 
   // cout << "In remove " << _task << endl;
		for (int i = 0; i < tasks.size(); i++) 
		{  
			
			//cout << tasks[i] << endl;
			if (tasks[i].find(_task)!= string::npos) 
			{
				tasks.erase(tasks.begin() + i);
				//cout << i << endl;
			}
		}
		return 1;
	}

    /*
    *   Prints out the full todo list to the console
    */
    virtual void printTodoList()
		{
		/*
    *   Method 1: Doing the vector method 
    */
    //for (int i = 0 ; i < tasks.size();i++)
		//cout << "Printing List" << endl;
		//cout << tasks[i] << endl;
			
		/*
    *   Method 2: Reread the file 
    */

		//cout << "Printing List" << endl;
		ifstream infile ("TODOList.txt");
		if (infile.is_open())
			  cout << infile.rdbuf() <<endl;
				infile.close();
			
		}
	/*
  *   Prints out all items of a todo list with a particular due date (specified by _duedate)
  */

/*
 *   METHOD 1 compare method
*/

   
    virtual void printDaysTasks(string _date) 
		{
			//cout << "All the Tasks on " << _date << endl;
				ifstream infile ("TODOList.txt");
				if (infile.is_open())
				{
				   string line;
					 string str1 = _date;

					 infile >> line;
					 while(!infile.eof()) // check end file is not in the file

					 //while (getline(infile,line))
					 { 
						 //cout << line << endl;
						 if (line.compare(str1) == 0)
						 {
							 infile >> line ;
							 cout << "Task on that day is " << endl << line << endl;
						 }
						 else 
						 {
							 infile >> line ;
						 }
          
					 }
					 infile.close();
				}
		}	
		



/*
 *   METHOD 2 using another vector and use 
*/
	/*
		virtual void printDaysTasks(string _date) 
		{
			//cout << "In printDaysTasks" << endl;
			//cout << _date << ": " << endl;
        for (int i = 0; i < tasks.size(); i++) 
				{
            if (tasks[i].find(_date) != string::npos) 
						{ 
							vector<string> temp;
							//Constructs a istringstream object:
							istringstream TS(tasks[i]);
                string N;
								while (TS >> NS)
								{
									temp.push_back(NS);
									// cout << NS << endl;
								}
								for (int j = 1 ; j < temp.size();j++)
								{
									 cout << temp[j] << endl;
								}
								 
								
            }
        }
    }
		*/
	

/*
 *   METHOD 3 creat a string and replace
*/

/*
	void printDaysTasks(string _date) {

    //cout << " All tasks for " << _date  << endl;
		for(int i = 0; i < tasks.size(); i++) {
			if(tasks.at[i].find(_date) != string::npos) {
				string TString;
				TString = tasks.at[i];
				TString = TString.replace(0, _date.length() + 1, "");
				cout << TString << endl;
			}
		}


    }
*/

	
};
	

				
			


#endif