#pragma once
#include <iostream>
#include <string>
#include "QSInterface.h"

using namespace std;

class QS : public QSInterface 
{
private:
    int *array;
    int size;
    int pos;  
public:
	QS();
	~QS();
	
	bool createArray(int capacity);
	bool addToArray(int value);
	string getArray() const;
	int getSize() const;
	void clear();
  
  int medianOfThree(int left, int right);
	int partition(int left, int right, int pivotIndex);
	void sortAll();
	void sortAll(int left, int right);
};